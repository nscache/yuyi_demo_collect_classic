//
//  ViewController.h
//  暴走天气
//
//  Created by 研究院 on 12-10-23.
//  Copyright (c) 2012年 研究院. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UIActivityIndicatorView *activityIndicator;
    NSString *outString;
    NSString *city;
    NSString *weather;
    NSString *temp ;
    UILabel *citylabel;
    UILabel *weatherlabel;
    UILabel *templabel;
    
}
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, retain) IBOutlet UILabel *citylabel;
@property (nonatomic, retain) IBOutlet UILabel *weatherlabel;
@property (nonatomic, retain) IBOutlet UILabel *templabel;

@end
