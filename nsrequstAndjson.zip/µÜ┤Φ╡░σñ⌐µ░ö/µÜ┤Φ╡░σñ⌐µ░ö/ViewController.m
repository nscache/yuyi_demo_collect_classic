//
//  ViewController.m
//  暴走天气
//
//  Created by 研究院 on 12-10-23.
//  Copyright (c) 2012年 研究院. All rights reserved.
//

#import "ViewController.h"
#import "JSON.h"
@interface ViewController ()

@end

@implementation ViewController

@synthesize activityIndicator;
@synthesize templabel;
@synthesize weatherlabel;
@synthesize citylabel;
- (void)viewDidLoad
{
    [super viewDidLoad];
    [activityIndicator startAnimating];
    NSString *googleURL = @"http://www.weather.com.cn/data/cityinfo/101280101.html";
	NSURL *url = [NSURL URLWithString:googleURL];
	
	NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
	
	NSURLConnection *connection = [[NSURLConnection alloc]
								   initWithRequest:request
								   delegate:self];
	
	[connection release];
	[request release];
	
	[activityIndicator startAnimating];
	
	// Do any additional setup after loading the view, typically from a nib.
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	outString = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
	NSLog(@"%@", outString);
}

-(void) connection:(NSURLConnection *)connection
  didFailWithError: (NSError *)error {
	UIAlertView *errorAlert = [[UIAlertView alloc]
							   initWithTitle: [error localizedDescription]
							   message: [error localizedFailureReason]
							   delegate:nil
							   cancelButtonTitle:@"OK"
							   otherButtonTitles:nil];
	[errorAlert show];
	[errorAlert release];
	[activityIndicator stopAnimating];
}

- (void) connectionDidFinishLoading: (NSURLConnection*) connection {
	[activityIndicator stopAnimating];
	
    NSMutableDictionary *jsonoObj = [outString JSONValue]; NSLog(@"%@", jsonoObj);
    NSMutableDictionary *jsonoSubObj = [jsonoObj objectForKey:@"weatherinfo"];
    city = [[NSString alloc] initWithFormat:@"%@\n",[jsonoSubObj objectForKey:@"city"]];
   
    weather =[[NSString alloc] initWithFormat:@"%@\n",[jsonoSubObj objectForKey:@"weather"]];

    temp =[[NSString alloc] initWithFormat:@"%@\n",[jsonoSubObj objectForKey:@"temp1"]];
    citylabel.text = city;
    weatherlabel.text = weather;
    templabel.text = temp;

   // textView.text = text; [text release];
    [outString release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

-(void)dealloc
{
    [activityIndicator release];
    [super dealloc];
}
@end
