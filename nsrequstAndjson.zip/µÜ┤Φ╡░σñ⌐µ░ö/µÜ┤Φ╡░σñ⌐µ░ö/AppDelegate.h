//
//  AppDelegate.h
//  暴走天气
//
//  Created by 研究院 on 12-10-23.
//  Copyright (c) 2012年 研究院. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
