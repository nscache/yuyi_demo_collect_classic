//
//  MessageWindow.h
//  NotificationDemo
//
//  Created by 俞 億 on 12-6-1.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageWindow : UIWindow{
    NSMutableArray *messageArray;
    UILabel *messageLabel;
}
@end
