//
//  DeptEntity.h
//  SqliteDemo
//
//  Created by 俞 億 on 12-5-31.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeptEntity : NSObject
@property(nonatomic,retain) NSString *deptName;
@property(nonatomic,retain) NSMutableArray *personArray;
@end
