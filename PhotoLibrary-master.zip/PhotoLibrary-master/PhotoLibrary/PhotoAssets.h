//
//  PhotoAssets.h
//  PhotoLibrary
//
//  Created by 刘 大兵 on 12-5-11.
//  Copyright (c) 2012年 中华中等专业学校. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PhotoAssets : NSObject
@property(nonatomic,retain) UIImage *thumnail;
@property(nonatomic,retain) UIImage *fullImage;
@end
