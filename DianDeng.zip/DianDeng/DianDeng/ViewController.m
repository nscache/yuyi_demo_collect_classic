//
//  ViewController.m
//  DianDeng
//
//  Created by LuoShuai on 12-11-14.
//  Copyright (c) 2012年 LuoShuai. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    isKaiGuan = YES;
    UIImage *image = nil;
    image = [UIImage imageNamed:@"back_image"];
    UIImageView *backGroudImage = [[UIImageView alloc]initWithImage:image];
    backGroudImage.frame = CGRectMake(0, 0, 320, 480);
    [self.view addSubview:backGroudImage];
    [backGroudImage release];
    
    image = [UIImage imageNamed:@"kaiguan_image"];
    kaiGuanImage = [[UIImageView alloc]initWithImage:image];
    kaiGuanImage.frame = CGRectMake(0, -37, 320, image.size.height);
    kaiGuanImage.tag = 100;
    [self.view insertSubview:kaiGuanImage belowSubview:backGroudImage];

    
    
    kaiBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [kaiBtn setFrame:CGRectMake(134, 108, 55, 114)];
    [kaiBtn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:kaiBtn];
    


    
    
}

-(void)click:(id)sendr
{

        
        AVCaptureDevice *captureDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        NSError *error = nil;
        if ([captureDevice hasTorch])
        {
            BOOL locked = [captureDevice lockForConfiguration:&error];
            if (locked) {
                if (isKaiGuan) {
                    [UIView animateWithDuration:.3f animations:^{
                        kaiGuanImage.frame = CGRectMake(0, 70, kaiGuanImage.frame.size.width, kaiGuanImage.frame.size.height);
                        kaiBtn.frame = CGRectMake(134, 108+137, 55, 114);
                    }];
                    captureDevice.torchMode = AVCaptureTorchModeOn;
                }else
                {
                    [UIView animateWithDuration:.3f animations:^{
                        kaiGuanImage.frame = CGRectMake(0, -37, kaiGuanImage.frame.size.width, kaiGuanImage.frame.size.height);
                        kaiBtn.frame = CGRectMake(134, 108, 55, 114);
                    }];
                    captureDevice.torchMode = AVCaptureTorchModeOff;
                }
                
                [captureDevice unlockForConfiguration];
            }
        }
    isKaiGuan = !isKaiGuan;
    NSLog(@"isKaiGuan==%@",isKaiGuan == YES ? @"yes":@"no");
}



-(void)dealloc
{
    [kaiGuanImage release];
    [super dealloc];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
