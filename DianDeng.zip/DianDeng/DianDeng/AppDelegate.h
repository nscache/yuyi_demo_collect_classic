//
//  AppDelegate.h
//  DianDeng
//
//  Created by LuoShuai on 12-11-14.
//  Copyright (c) 2012年 LuoShuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
