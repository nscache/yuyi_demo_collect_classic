//
//  ViewController.h
//  DianDeng
//
//  Created by LuoShuai on 12-11-14.
//  Copyright (c) 2012年 LuoShuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    BOOL isKaiGuan;
    UIImageView *kaiGuanImage;
    UIButton *kaiBtn;
}
@end
