//
//  ViewController.h
//  GestureDemo3
//
//  Created by 刘 大兵 on 12-5-2.
//  Copyright (c) 2012年 中华中等专业学校. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIGestureRecognizerDelegate>{
    IBOutlet UIScrollView *gestureScrollView;
}
@end
