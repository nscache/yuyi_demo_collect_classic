//
//  CustomPlayerView.h
//  VideoStreamDemo2
//
//  Created by 刘 大兵 on 12-5-17.
//  Copyright (c) 2012年 中华中等专业学校. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface CustomPlayerView : UIView
@property(nonatomic,retain) AVPlayer *player;
@end
