//
//  CustomPolyline.m
//  MapDemo2
//
//  Created by 俞 億 on 12-5-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CustomPolyline.h"

@implementation CustomPolyline
@synthesize step;
@end
