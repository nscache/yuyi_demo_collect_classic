//
//  CustomPolyline.h
//  MapDemo2
//
//  Created by 俞 億 on 12-5-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface CustomPolyline : MKPolyline
@property(nonatomic) NSInteger step;
@end
