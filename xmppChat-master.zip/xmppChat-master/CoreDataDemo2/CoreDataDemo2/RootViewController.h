//
//  RootViewController.h
//  CoreDataDemo2
//
//  Created by 俞 億 on 12-5-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@end
