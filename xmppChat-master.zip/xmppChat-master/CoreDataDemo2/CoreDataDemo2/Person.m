//
//  Person.m
//  CoreDataDemo2
//
//  Created by 俞 億 on 12-5-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "Person.h"
#import "Group.h"


@implementation Person

@dynamic name;
@dynamic groupArray;

@end
