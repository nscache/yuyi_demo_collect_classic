#import <Cocoa/Cocoa.h>

@interface TestXEP82AppDelegate : NSObject <NSApplicationDelegate>
{
	__unsafe_unretained NSWindow *window;
}

@property (unsafe_unretained) IBOutlet NSWindow *window;

@end
