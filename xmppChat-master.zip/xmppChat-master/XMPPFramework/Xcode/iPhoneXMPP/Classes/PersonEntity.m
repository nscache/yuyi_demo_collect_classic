//
//  PersonEntity.m
//  iPhoneXMPP
//
//  Created by 俞 億 on 12-5-31.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "PersonEntity.h"
#import "MessageEntity.h"


@implementation PersonEntity

@dynamic name;
@dynamic sendedMessages;

@end
