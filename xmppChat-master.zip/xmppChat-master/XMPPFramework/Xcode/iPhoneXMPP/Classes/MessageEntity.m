//
//  MessageEntity.m
//  iPhoneXMPP
//
//  Created by 俞 億 on 12-5-31.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "MessageEntity.h"
#import "PersonEntity.h"


@implementation MessageEntity

@dynamic content;
@dynamic flag_sended;
@dynamic sendDate;
@dynamic flag_readed;
@dynamic receiver;
@dynamic sender;

@end
