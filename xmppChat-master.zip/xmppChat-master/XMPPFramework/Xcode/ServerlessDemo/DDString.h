#import <Foundation/Foundation.h>


@interface NSString (DDString)

+ (id)stringWithUTF8Data:(NSData *)data;

@end
